#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

extern "C"
{
    double ExecuteShell(char *fname,double wait)
    {
        if (wait < 1)
        {
            if (fork() == 0)
            {
                system(fname);
                exit(0);
            }

        }
        else
        {
            system(fname);
        }
        return 0;
    }
}
