#include "main.h"
#define DLL extern "C" _declspec(dllexport)

DLL double ExecuteShell(char *fname,double wait)
{
    PROCESS_INFORMATION ProcessInfo;

    STARTUPINFO StartupInfo;

    ZeroMemory(&StartupInfo, sizeof(StartupInfo));
    StartupInfo.cb = sizeof StartupInfo;

    if(CreateProcess(NULL, fname,
        NULL,NULL,FALSE,0,NULL,
        NULL,&StartupInfo,&ProcessInfo))
    {
        if (wait >=1)
        {
            WaitForSingleObject(ProcessInfo.hProcess,INFINITE);
        }

        CloseHandle(ProcessInfo.hThread);
        CloseHandle(ProcessInfo.hProcess);
    }

	return 0;
}
